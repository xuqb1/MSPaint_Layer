package mspaint.utils;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

//import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;

public class Debug {
    //private static final Logger LOGGER= LoggerFactory.getLogger(Debug.class);
    public static void println(String str) {
        StackTraceElement ste = Thread.currentThread().getStackTrace()[2];
        String methodName = ste.getMethodName();
        String lineNumber = ste.getLineNumber() + "";
        String className = ste.getClassName();
    }

    public static void info(String str){
        StackTraceElement ste = Thread.currentThread().getStackTrace()[2];
        String methodName = ste.getMethodName();
        String lineNumber = ste.getLineNumber() + "";
        String className = ste.getClassName();
        //LOGGER.info(className + "." + methodName + " " + lineNumber + " " + str);
        System.out.println("[info] " + className + "." + methodName + " " + lineNumber + " " + str);
    }
    public static void error(String str){
        StackTraceElement ste = Thread.currentThread().getStackTrace()[2];
        String methodName = ste.getMethodName();
        String lineNumber = ste.getLineNumber() + "";
        String className = ste.getClassName();
        System.out.println("[error] " + className + "." + methodName + " " + lineNumber + " " + str);
    }
    public static void time(long starttime,long endtime){
        StackTraceElement ste = Thread.currentThread().getStackTrace()[2];
        String methodName = ste.getMethodName();
        String lineNumber = ste.getLineNumber() + "";
        String className = ste.getClassName();
        System.out.println("[time] " + className + "." + methodName + " " + lineNumber + " " + (endtime-starttime));
    }
}
