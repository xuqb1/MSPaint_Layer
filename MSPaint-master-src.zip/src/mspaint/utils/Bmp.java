package mspaint.utils;

import java.awt.image.BufferedImage;
import java.io.*;

public class Bmp {
    public static void writeBMP(BufferedImage image, File f) throws IOException {
        OutputStream out = new BufferedOutputStream(new FileOutputStream(f));
        int width = image.getWidth();
        int height = image.getHeight();
        int row = (width * 3 + 3) / 4 * 4;
        out.write('B');
        out.write('M');
        writeInt(out, 14 + 40 + row * height);  // file size
        writeInt(out, 0);
        writeInt(out, 14 + 40);        // bitmap offset
        writeInt(out, 40);             // size
        writeInt(out, width);          // width
        writeInt(out, height);         // weight
        writeInt(out, (24<<16) | 1);   // planes, bpp
        writeInt(out, 0);              // compression
        writeInt(out, row * height);   // bitmap size
        writeInt(out, 0);              // resx
        writeInt(out, 0);              // resy
        writeInt(out, 0);              // used colors
        writeInt(out, 0);              // important colors
        for (int y=height-1;y>=0;y--) {
            for (int x=0;x<width;x++) {
                int rgba = image.getRGB(x, y);
                out.write(rgba & 0xFF); // b
                out.write(rgba >> 8);   // g
                out.write(rgba >> 16);  // r
            }
            for (int x=width*3;x%4!=0;x++) { // pad to 4 bytes
                out.write(0);
            }
        }
        out.close();
    }
    private static void writeInt(OutputStream out, int v) throws IOException {
        out.write(v);
        out.write(v >> 8);
        out.write(v >> 16);
        out.write(v >> 24);
    }
}
