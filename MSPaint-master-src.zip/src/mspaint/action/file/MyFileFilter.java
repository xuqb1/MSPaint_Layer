package mspaint.action.file;

import javax.swing.filechooser.FileFilter;
import java.io.File;

public class MyFileFilter  extends FileFilter {
    String ends;  //文件后缀
    String description;  // 文件描述文字
    public MyFileFilter(String ends, String description) { //构造函数
        this.ends=ends;
        this.description =description;
    }

    //只显示符合扩展名的文件，目录全部显示
    @Override
    public boolean accept(File file) {
        if (file.isDirectory()) return true ;
        String fileName = file.getName();
        if (fileName.toUpperCase().endsWith( this.ends.toUpperCase()))
            return true;
        return false;
    }

    //返回这个扩展名过滤器的描述
    @Override
    public String getDescription() {
        if(this.description == null){
            return "*";
        }
        return this.description;
    }
    //返回这个扩展名过滤器的扩展名
    public String getEnds() {
        return this.ends;
    }
}