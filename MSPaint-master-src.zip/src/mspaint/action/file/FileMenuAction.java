package mspaint.action.file;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.sun.deploy.util.StringUtils;
import mspaint.action.MainViewAction;
import mspaint.gui.GUIHandler;
import mspaint.gui.menubar.FilePopupMenu;
import mspaint.helper.ImageFilter;
import mspaint.helper.TButton;
import mspaint.utils.Bmp;
import mspaint.utils.Debug;

/**
 * FileMenuAction
 */
public class FileMenuAction implements ActionListener {
    private GUIHandler gui;
    private FilePopupMenu menu;

    public FileMenuAction(GUIHandler gui, FilePopupMenu menu) {
        this.gui = gui;
        this.menu = menu;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        TButton button = (TButton) e.getSource();

        if (menu.isShowing()) {
            menu.setVisible(false);
        }

        if (button.getText().equals("新建")) {
            if (gui.isSelectionActive) {
                gui.viewAction.drawImageSelected();
            }
            MainViewAction.clearImage(gui.mainImage);
            MainViewAction.clearImage(gui.tempImage);
        } else if (button.getText().equals("打开")) {

        } else if (button.getText().equals("保存")) {
            saveImage();
        } else if (button.getText().equals("另存为")) {
            saveImage();
        } else if (button.getText().equals("打印")) {
            PrinterJob pj = PrinterJob.getPrinterJob();
            if (pj.printDialog()) {
                try {
                    pj.print();
                } catch (PrinterException e2) {
                    Debug.info(e2.getMessage());
                    e2.printStackTrace();
                }
            }
        } else if (button.getText().equals("设置为桌面背景")) {

        } else if (button.getText().equals("关于")) {

        } else if (button.getText().equals("退出")) {
            System.exit(0);
        } else if (button.getName().equals("png")) {
            saveImage("image.png", "PNG文件", "png");
        } else if (button.getName().equals("jpeg")) {
            saveImage("image.jpeg", "JPEG文件", "jpeg");
        } else if (button.getName().equals("bmp")) {
            saveImage("image.bmp", "BMP文件", "bmp");
        } else if (button.getName().equals("gif")) {
            saveImage("image.gif", "GIF文件", "gif");
        } else if (button.getName().equals("pnz")) {
            saveImage();
        }
    }

    private void saveImage(String defaultName, String description, String extension) {
        JFileChooser chooser = new JFileChooser();
        ImageFilter imgFilter = new ImageFilter();
        chooser.addChoosableFileFilter(imgFilter);
        //chooser.addChoosableFileFilter(new ImageFilter(description, extension));
        chooser.setAcceptAllFileFilterUsed(false);
        {
            chooser.setFileFilter(new FileNameExtensionFilter(description, extension));
            chooser.setSelectedFile(new File(defaultName));
        }
        int value = chooser.showSaveDialog(gui.frame);
        if (value == JFileChooser.APPROVE_OPTION) {
            BufferedImage image;
            {
                image = gui.mainImage;
            }
            File file = chooser.getSelectedFile();
            String ext = extension;//imgFilter.getExtension(file);
            Debug.info("File = " + file);
            Debug.info("exten = " + ext);
            try {
                ImageIO.write(image, ext, file);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    private void saveImage() {
        JFileChooser chooser = new JFileChooser();
        //ImageFilter imgFilter = new ImageFilter();
        //chooser.addChoosableFileFilter(imgFilter);
        chooser.setAcceptAllFileFilterUsed(false);
        {
            /*
            chooser.setFileFilter(new FileNameExtensionFilter("BMP文件","bmp"));
            chooser.setFileFilter(new FileNameExtensionFilter("JPG文件","jpg"));
            chooser.setFileFilter(new FileNameExtensionFilter("JPEG文件","jpeg"));
            chooser.setFileFilter(new FileNameExtensionFilter("GIF文件","gif"));
            chooser.setFileFilter(new FileNameExtensionFilter("PNG文件","png"));

            //chooser.addChoosableFileFilter(new MyFileFilter( ".txt","txt 文件 (*.txt)"));
            chooser.addChoosableFileFilter(new MyFileFilter( "bmp","BMP文件"));
            chooser.addChoosableFileFilter(new MyFileFilter( "JPG","JPG文件"));
            chooser.addChoosableFileFilter(new MyFileFilter( "gif","GIF文件"));
            chooser.addChoosableFileFilter(new MyFileFilter( "png","PNG文件"));*/

            chooser.setFileFilter(new MyFileFilter("bmp", "BMP文件"));
            chooser.setFileFilter(new MyFileFilter("JPG", "JPG文件"));
            chooser.setFileFilter(new MyFileFilter("gif", "GIF文件"));
            chooser.setFileFilter(new MyFileFilter("png", "PNG文件"));

            chooser.setSelectedFile(new File("image.png"));
        }
        int value = chooser.showSaveDialog(gui.frame);
        if (value == JFileChooser.APPROVE_OPTION) {
            BufferedImage image;
            {
                image = gui.mainImage;
            }
            File file = chooser.getSelectedFile();
            Debug.info("File = " + file);
            String filename = file.getName();
            Debug.info("filename=" + filename);
            String fext = ((MyFileFilter) chooser.getFileFilter()).getEnds();
            String ext = fext;
            if (filename.indexOf(".") > 0 && filename.indexOf(".") < filename.length() - 1) {
                ext = filename.toLowerCase().substring(filename.lastIndexOf(".") + 1);
            }
            String matchStr = ".bmp.jpg.jpeg.png.gif.";
            if (!ext.equals(fext)) {
                if (matchStr.indexOf("." + ext + ".") >= 0) {
                    filename = filename.substring(0, filename.lastIndexOf("."));
                }
                filename = filename + "." + fext;

                file = new File(file.getParent() + File.separator + filename);
                Debug.info("file = " + file);
            }
            if(!filename.endsWith("."+fext)){
                filename = filename + "." + fext;
                file = new File(file.getParent() + File.separator + filename);
                Debug.info("file = " + file);
            }

            Debug.info("file exten =Image " + fext);
            Debug.info("chooser.filter ext=" + chooser.getFileFilter().toString());
            try {
                if(!fext.equals("bmp")) {
                    ImageIO.write(image, fext.toUpperCase(), file);
                }else{
                    BufferedImage bi = new BufferedImage(image.getWidth(),image.getHeight(),BufferedImage.TYPE_INT_RGB);
                    bi.createGraphics().drawImage(image, 0, 0, Color.WHITE, null);
                    boolean tf = ImageIO.write(bi, fext.toUpperCase(), file);
                    bi = null;
                    image = null;
                    Debug.info("ImageIO.write return : " + tf);
                    //Bmp.writeBMP(image,file);
                }
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}