package mspaint.style;

import java.awt.Font;

public interface Style {

    Font getFont();
    
}
