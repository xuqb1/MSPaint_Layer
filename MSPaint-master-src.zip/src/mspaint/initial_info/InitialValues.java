package mspaint.initial_info;

import java.awt.Dimension;

public class InitialValues {
    public static Dimension frameSize = new Dimension(1300, 670);
    public static int newImageWidth = 600;
    public static int newImageHeight = 400;
    public static int sidePanelWith = 180;
}
